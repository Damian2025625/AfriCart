'use client';
import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePathname } from 'next/navigation';
import { FiGlobe, FiCheck, FiLoader } from 'react-icons/fi';

const languages = [
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'ig', name: 'Igbo', flag: '🇳🇬' },
  { code: 'yo', name: 'Yoruba', flag: '🇳🇬' },
  { code: 'ha', name: 'Hausa', flag: '🇳🇬' },
];

export default function LanguageSelector() {
  const { targetLang, switchLanguage, isTranslating, setIsTranslating } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();
  const isTranslatingRef = useRef(false);
  const lastTranslatedPageRef = useRef(null);

  // Function to check if page has REAL content (not just loader)
  const waitForRealContent = async () => {
    console.log('⏳ Waiting for real content to load...');
    
    let attempts = 0;
    const maxAttempts = 20; // Try for 4 seconds (20 * 200ms)

    while (attempts < maxAttempts) {
      // Check if loading spinner is gone
      const hasSpinner = document.querySelector('.animate-spin');
      
      // Check if there's actual content (more than just "Loading...")
      const mainContent = document.querySelector('main') || document.body;
      const textContent = mainContent.textContent || '';
      const hasRealContent = textContent.length > 100; // Real pages have more than 100 chars
      
      // Check for common content indicators
      const hasButtons = document.querySelectorAll('button').length > 3;
      const hasLinks = document.querySelectorAll('a').length > 3;
      const hasImages = document.querySelectorAll('img').length > 0;

      if (!hasSpinner && hasRealContent && (hasButtons || hasLinks || hasImages)) {
        console.log('✅ Real content detected!');
        return true;
      }

      console.log(`⏳ Attempt ${attempts + 1}/${maxAttempts} - Still waiting...`);
      await new Promise(resolve => setTimeout(resolve, 200));
      attempts++;
    }

    console.warn('⚠️ Timeout waiting for content, proceeding anyway');
    return true;
  };

  const translatePage = async (langName) => {
    // Prevent multiple simultaneous translations
    if (isTranslatingRef.current) {
      console.log('⏭️ Translation already in progress, skipping');
      return;
    }

    // Check if we already translated this page to this language
    const currentPageKey = `${pathname}:${langName}`;
    if (lastTranslatedPageRef.current === currentPageKey) {
      console.log('✅ Page already translated to', langName);
      return;
    }

    if (langName === 'English') {
      // Restore original text
      const allElements = document.querySelectorAll('[data-original-text]');
      allElements.forEach(el => {
        const original = el.getAttribute('data-original-text');
        if (original) {
          const textNode = Array.from(el.childNodes).find(n => n.nodeType === Node.TEXT_NODE);
          if (textNode) {
            textNode.nodeValue = original;
          }
        }
        el.removeAttribute('data-translated');
      });
      lastTranslatedPageRef.current = null;
      return;
    }

    isTranslatingRef.current = true;
    setIsTranslating(true);

    try {
      // WAIT FOR REAL CONTENT TO LOAD (not just the loader)
      await waitForRealContent();

      // Extra buffer to ensure everything is rendered
      await new Promise(resolve => setTimeout(resolve, 500));

      const targetElement = document.querySelector('main') || document.body;

      const nodes = [];
      const texts = [];
      const walker = document.createTreeWalker(targetElement, NodeFilter.SHOW_TEXT);
      let node;

      while (node = walker.nextNode()) {
        const text = node.nodeValue?.trim();
        const parent = node.parentElement;

        // Skip if:
        // - No text or too short
        // - Inside script/style
        // - Inside loader/spinner
        // - Already translated
        // - Only contains "Loading..." or similar
        if (
          text &&
          text.length > 1 && 
          !parent.closest('script, style, noscript, .no-translate, [role="status"], .animate-spin, [class*="loading"]') &&
          parent.getAttribute('data-translated') !== langName &&
          !text.match(/^(Loading|Please wait|Fetching)/i) // Skip loader text
        ) {
          // Store original text ONCE
          if (!parent.hasAttribute('data-original-text')) {
            parent.setAttribute('data-original-text', text);
          }

          nodes.push(node);
          texts.push(text);
        }
      }

      console.log(`🌍 Found ${texts.length} text nodes to translate to ${langName}`);

      if (texts.length === 0) {
        console.warn('⚠️ No text found to translate');
        lastTranslatedPageRef.current = currentPageKey;
        return;
      }

      const chunkSize = 15;
      for (let i = 0; i < texts.length; i += chunkSize) {
        const batch = texts.slice(i, i + chunkSize);
        
        console.log(`📦 Batch ${Math.floor(i/chunkSize) + 1}/${Math.ceil(texts.length/chunkSize)}`);
        
        const res = await fetch('/api/translate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ textBatch: batch, targetLang: langName }),
        });
        
        if (!res.ok) {
          console.error('❌ Translation API error:', res.status);
          continue;
        }

        const data = await res.json();
        
        if (data.translatedBatch) {
          data.translatedBatch.forEach((translatedText, index) => {
            const nodeIndex = i + index;
            if (nodes[nodeIndex] && nodes[nodeIndex].parentElement) {
              nodes[nodeIndex].nodeValue = translatedText;
              nodes[nodeIndex].parentElement.setAttribute('data-translated', langName);
            }
          });
          console.log(`✅ Batch ${Math.floor(i/chunkSize) + 1} complete`);
        }

        // Small delay between batches
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      console.log('🎉 Translation complete!');
      lastTranslatedPageRef.current = currentPageKey;

    } catch (err) {
      console.error("❌ Translation Failed:", err);
    } finally {
      isTranslatingRef.current = false;
      setIsTranslating(false);
    }
  };

  // AUTO-TRANSLATE when page changes
  useEffect(() => {
    console.log(`📄 Page changed: ${pathname}, Language: ${targetLang}`);

    if (targetLang !== 'English') {
      // Small initial delay to let Next.js start rendering
      const timer = setTimeout(() => {
        translatePage(targetLang);
      }, 300);
      
      return () => clearTimeout(timer);
    }
  }, [pathname, targetLang]);

  const current = languages.find(l => l.name === targetLang) || languages[0];

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={isTranslating}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg border bg-white hover:bg-gray-50 transition-all shadow-sm ${
          isTranslating ? 'opacity-75 cursor-not-allowed' : ''
        }`}
      >
        {isTranslating ? (
          <FiLoader className="animate-spin text-green-600" />
        ) : (
          <FiGlobe className="text-gray-600" />
        )}
        <span className="font-medium text-gray-700 hidden sm:inline">
          {current.flag} {current.name}
        </span>
        <span className="sm:hidden text-xl">{current.flag}</span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 z-50 overflow-hidden">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => {
                  setIsOpen(false);
                  switchLanguage(lang.name);
                  lastTranslatedPageRef.current = null;
                  translatePage(lang.name);
                }}
                disabled={isTranslating}
                className={`w-full flex items-center justify-between px-4 py-3 text-sm hover:bg-green-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                  targetLang === lang.name ? 'bg-green-50 text-green-700' : 'text-gray-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">{lang.flag}</span>
                  <span className="font-medium">{lang.name}</span>
                </div>
                {targetLang === lang.name && <FiCheck />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}