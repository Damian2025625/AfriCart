import { NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import connectDB from '@/lib/mongodb/config';
import Order from '@/lib/mongodb/models/Order';
import Product from '@/lib/mongodb/models/Product';
import User from '@/lib/mongodb/models/User'; // Added this import
import Vendor from '@/lib/mongodb/models/Vendor'; // Added this import
import { sendEmail } from '@/lib/email/nodemailer';
import { sendSMS } from '@/lib/notifications';

export async function PATCH(request, { params }) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader) {
      return NextResponse.json(
        { success: false, message: 'No token provided' },
        { status: 401 }
      );
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.role !== 'CUSTOMER') {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 403 }
      );
    }

    const { orderNumber } = await params;
    const { reason } = await request.json();

    await connectDB();

    const customer = await User.findById(decoded.userId);

    // Find master order
    const masterOrder = await Order.findOne({
      orderNumber,
      customerId: decoded.userId,
      isMasterOrder: true,
    });

    if (!masterOrder) {
      return NextResponse.json(
        { success: false, message: 'Order not found' },
        { status: 404 }
      );
    }

    // Check if order can be cancelled
    if (!['PENDING', 'CONFIRMED'].includes(masterOrder.orderStatus)) {
      return NextResponse.json(
        { success: false, message: 'Order cannot be cancelled at this stage' },
        { status: 400 }
      );
    }

    // ✅ Cancel all sub-orders
    const subOrders = await Order.find({
      masterOrderId: masterOrder._id,
      isMasterOrder: false,
    });

    // 🔔 COLLECT VENDORS TO NOTIFY
    const vendorNotifications = [];

    for (const subOrder of subOrders) {
      // Restore stock for each item
      for (const item of subOrder.items) {
        await Product.findByIdAndUpdate(item.productId, {
          $inc: { 
            quantity: item.quantity,
            totalSold: -item.quantity 
          },
        });
      }

      // Cancel sub-order
      subOrder.orderStatus = 'CANCELLED';
      subOrder.cancelledAt = new Date();
      subOrder.cancellationReason = reason || 'Customer cancelled';
      await subOrder.save();

      // 🔔 GET VENDOR INFO FOR NOTIFICATION
      const vendor = await Vendor.findById(subOrder.vendorId).populate('userId');
      
      if (vendor && vendor.userId) {
        vendorNotifications.push({
          vendor,
          vendorUser: vendor.userId,
          subOrder,
        });
      }

      console.log(`✅ Cancelled sub-order ${subOrder.orderNumber}`);
    }

    // ✅ Cancel master order
    masterOrder.orderStatus = 'CANCELLED';
    masterOrder.cancelledAt = new Date();
    masterOrder.cancellationReason = reason || 'Customer cancelled';
    await masterOrder.save();

    console.log(`✅ Cancelled master order ${orderNumber}`);
    console.log(`   Total sub-orders cancelled: ${subOrders.length}`);

    // 🔔 SEND CANCELLATION NOTIFICATIONS TO VENDORS (non-blocking)
    const notificationPromises = vendorNotifications.map(({ vendor, vendorUser, subOrder }) => {
      const customerName = `${customer.firstName} ${customer.lastName}`;
      
      // SMS to vendor
      const sms = sendSMS(
        vendorUser.phone,
        `ORDER CANCELLED!\nOrder #${subOrder.orderNumber} cancelled by ${customerName}.\nReason: ${reason || 'Not provided'}\nStock has been restored.`
      ).catch(err => console.error('SMS error:', err));

      // Email to vendor
      const email = sendEmail({
        to: vendorUser.email,
        subject: `Order Cancelled - ${subOrder.orderNumber}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #dc2626; color: white; padding: 20px; text-align: center;">
              <h1>❌ Order Cancelled</h1>
            </div>
            <div style="padding: 30px; background: #f9fafb;">
              <p>Hello ${vendorUser.firstName},</p>
              <p>Order <strong>#${subOrder.orderNumber}</strong> has been cancelled by the customer.</p>
              <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p><strong>Customer:</strong> ${customerName}</p>
                <p><strong>Reason:</strong> ${reason || 'Not provided'}</p>
                <p><strong>Order Total:</strong> ₦${subOrder.total.toLocaleString()}</p>
              </div>
              <p>The stock has been automatically restored to your inventory.</p>
              <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
                © ${new Date().getFullYear()} AfriCart. All rights reserved.
              </p>
            </div>
          </div>
        `,
      }).catch(err => console.error('Email error:', err));

      return Promise.all([sms, email]);
    });

    // Wait for all notifications (doesn't block response)
    Promise.all(notificationPromises).then(() => {
      console.log('✅ All vendor cancellation notifications sent');
    });

    return NextResponse.json({
      success: true,
      message: 'Order cancelled successfully',
      order: masterOrder,
    });
  } catch (error) {
    console.error('Cancel order error:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to cancel order' },
      { status: 500 }
    );
  }
}