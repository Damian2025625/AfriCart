import { NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb/config';
import Customer from '@/lib/mongodb/models/Customer';
import Conversation from '@/lib/mongodb/models/Conversation';
import Message from '@/lib/mongodb/models/Message';
import User from '@/lib/mongodb/models/User';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET;

// GET - Fetch messages
export async function GET(request, { params }) {
  try {
    const authHeader = request.headers.get('authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, message: 'No token provided' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    let decoded;
    
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (error) {
      return NextResponse.json(
        { success: false, message: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    if (decoded.role !== 'CUSTOMER') {
      return NextResponse.json(
        { success: false, message: 'Customers only' },
        { status: 403 }
      );
    }

    await connectDB();

    const { id: conversationId } = await params;
    const { searchParams } = new URL(request.url);
    const afterMessageId = searchParams.get('after'); // For incremental fetching

    const customer = await Customer.findOne({ userId: decoded.userId });
    
    if (!customer) {
      return NextResponse.json(
        { success: false, message: 'Customer not found' },
        { status: 404 }
      );
    }

    // Verify conversation belongs to customer
    const conversation = await Conversation.findOne({
      _id: conversationId,
      customerId: customer._id,
    });

    if (!conversation) {
      return NextResponse.json(
        { success: false, message: 'Conversation not found' },
        { status: 404 }
      );
    }

    // Build query
    const query = { conversationId };

    // If afterMessageId is provided, only fetch messages after that ID
    if (afterMessageId) {
      const afterMessage = await Message.findById(afterMessageId);
      if (afterMessage) {
        query.createdAt = { $gt: afterMessage.createdAt };
      }
    }

    const messages = await Message.find(query)
      .populate('senderId', 'firstName lastName')
      .sort({ createdAt: 1 });

    const transformedMessages = messages.map(message => ({
      _id: message._id.toString(),
      content: message.content,
      sender: message.senderId ? {
        _id: message.senderId._id.toString(),
        firstName: message.senderId.firstName,
        lastName: message.senderId.lastName,
      } : null,
      isRead: message.isRead,
      createdAt: message.createdAt,
    }));

    return NextResponse.json({
      success: true,
      messages: transformedMessages,
    });
  } catch (error) {
    console.error('Get messages error:', error);
    return NextResponse.json(
      { success: false, message: error.message || 'Failed to fetch messages' },
      { status: 500 }
    );
  }
}

// POST - Send message
export async function POST(request, { params }) {
  try {
    const authHeader = request.headers.get('authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, message: 'No token provided' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    let decoded;
    
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (error) {
      return NextResponse.json(
        { success: false, message: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    if (decoded.role !== 'CUSTOMER') {
      return NextResponse.json(
        { success: false, message: 'Customers only' },
        { status: 403 }
      );
    }

    await connectDB();

    const { id: conversationId } = await params;
    const body = await request.json();
    const { content } = body;

    if (!content || !content.trim()) {
      return NextResponse.json(
        { success: false, message: 'Message content is required' },
        { status: 400 }
      );
    }

    const customer = await Customer.findOne({ userId: decoded.userId });
    
    if (!customer) {
      return NextResponse.json(
        { success: false, message: 'Customer not found' },
        { status: 404 }
      );
    }

    // Verify conversation belongs to customer
    const conversation = await Conversation.findOne({
      _id: conversationId,
      customerId: customer._id,
    });

    if (!conversation) {
      return NextResponse.json(
        { success: false, message: 'Conversation not found' },
        { status: 404 }
      );
    }

    // Create message
    const message = await Message.create({
      conversationId,
      senderId: decoded.userId,
      content: content.trim(),
      isRead: false,
    });

    // Update conversation's last message
    await Conversation.findByIdAndUpdate(conversationId, {
      lastMessage: content.trim(),
      lastMessageAt: new Date(),
    });

    // Populate sender info
    const populatedMessage = await Message.findById(message._id)
      .populate('senderId', 'firstName lastName');

    const transformedMessage = {
      _id: populatedMessage._id.toString(),
      content: populatedMessage.content,
      sender: populatedMessage.senderId ? {
        _id: populatedMessage.senderId._id.toString(),
        firstName: populatedMessage.senderId.firstName,
        lastName: populatedMessage.senderId.lastName,
      } : null,
      isRead: populatedMessage.isRead,
      createdAt: populatedMessage.createdAt,
    };

    return NextResponse.json({
      success: true,
      message: transformedMessage,
    });
  } catch (error) {
    console.error('Send message error:', error);
    return NextResponse.json(
      { success: false, message: error.message || 'Failed to send message' },
      { status: 500 }
    );
  }
}