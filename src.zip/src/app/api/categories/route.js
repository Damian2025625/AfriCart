import { NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb/config';
import Category from '@/lib/mongodb/models/Category';

export async function GET() {
  try {
    await connectDB();

    const categories = await Category.find({ isActive: true })
      .sort({ name: 1 })
      .select('name description');

    return NextResponse.json({
      success: true,
      categories,
    });
  } catch (error) {
    console.error('Categories error:', error);
    return NextResponse.json(
      { success: false, message: 'Failed to fetch categories' },
      { status: 500 }
    );
  }
}