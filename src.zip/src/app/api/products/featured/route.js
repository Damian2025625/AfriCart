import { NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb/config';
import Product from '@/lib/mongodb/models/Product';
import Review from '@/lib/mongodb/models/Review';
import Category from '@/lib/mongodb/models/Category';
import Subcategory from '@/lib/mongodb/models/Subcategory';
import Vendor from '@/lib/mongodb/models/Vendor';

export async function GET(request) {
  try {
    await connectDB();

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit')) || 8;

    const products = await Product.find({ 
      isActive: true,
      images: { $ne: null, $not: { $size: 0 } }
    })
      .populate('categoryId', 'name')
      .populate('subcategoryId', 'name')
      .populate('vendorId', 'businessName city state')
      .sort({ createdAt: -1 })
      .limit(limit);

    // ✅ Calculate vendor ratings for all vendors (batch)
    const vendorIds = [...new Set(products.map(p => p.vendorId?._id?.toString()).filter(Boolean))];
    const vendorRatingsMap = {};

    for (const vendorId of vendorIds) {
      // Get all products by this vendor
      const vendorProducts = await Product.find({ vendorId }).select('_id');
      const vendorProductIds = vendorProducts.map(p => p._id);

      // Get all reviews for vendor products
      const vendorReviews = await Review.find({
        productId: { $in: vendorProductIds }
      }).select('rating');

      if (vendorReviews.length > 0) {
        const totalRating = vendorReviews.reduce((sum, review) => sum + review.rating, 0);
        vendorRatingsMap[vendorId] = {
          rating: Number((totalRating / vendorReviews.length).toFixed(1)),
          totalRatings: vendorReviews.length,
        };
      } else {
        vendorRatingsMap[vendorId] = {
          rating: 0,
          totalRatings: 0,
        };
      }
    }

    // Transform products
    const transformedProducts = products.map(product => {
      const vendorId = product.vendorId?._id?.toString();
      const vendorRating = vendorRatingsMap[vendorId] || { rating: 0, totalRatings: 0 };

      return {
        _id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.categoryId ? { name: product.categoryId.name } : null,
        subcategory: product.subcategoryId ? { name: product.subcategoryId.name } : null,
        vendor: product.vendorId ? {
          businessName: product.vendorId.businessName,
          city: product.vendorId.city,
          state: product.vendorId.state,
          rating: vendorRating.rating, // ✅ Calculated rating
          totalRatings: vendorRating.totalRatings, // ✅ Total reviews
        } : null,
        price: product.price,
        quantity: product.quantity,
        images: product.images,
        features: product.features,
        discountPercentage: product.discountPercentage,
        discountStartDate: product.discountStartDate,
        discountEndDate: product.discountEndDate,
        isActive: product.isActive,
        views: product.views,
        totalSold: product.totalSold,
        createdAt: product.createdAt,
      };
    });

    return NextResponse.json({
      success: true,
      products: transformedProducts,
    });
  } catch (error) {
    console.error('Featured products error:', error);
    return NextResponse.json(
      { success: false, message: error.message || 'Failed to fetch products' },
      { status: 500 }
    );
  }
}