import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import connectDB from "@/lib/mongodb/config";
import Product from "@/lib/mongodb/models/Product";
import Vendor from "@/lib/mongodb/models/Vendor";
import CustomProductPrice from "@/lib/mongodb/models/CustomProductPrice";
import axios from "axios";

const FLUTTERWAVE_SECRET_KEY = process.env.FLUTTERWAVE_SECRET_KEY;

async function getCustomPrice(productId, customerId) {
  try {
    const customPriceDoc = await CustomProductPrice.findOne({
      productId: productId,
      customerId: customerId,
      isActive: true,
      $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }],
    });
    return customPriceDoc ? customPriceDoc.customPrice : null;
  } catch (error) {
    console.error("Error fetching custom price:", error);
    return null;
  }
}

function verifyToken(request) {
  try {
    const authHeader = request.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) return null;
    const token = authHeader.substring(7);
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

export async function POST(request) {
  try {
    const user = verifyToken(request);
    if (!user || user.role !== "CUSTOMER") {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    await connectDB();
    const body = await request.json();
    const {
      email,
      amount,
      customerName,
      phone,
      cartItems = [],
      metadata = {},
    } = body;

    if (!cartItems || cartItems.length === 0) {
      return NextResponse.json(
        { success: false, message: "Cart is empty" },
        { status: 400 },
      );
    }

    const vendorData = new Map();
    const vendorsWithoutSubaccounts = [];

    for (const item of cartItems) {
      // 1. Populate the vendor data directly from the Product model
      const product = await Product.findById(item.productId).populate(
        "vendorId",
      );

      if (!product || !product.vendorId) continue;

      // 2. Logic fix: Because of .populate(), product.vendorId IS the vendor document
      const vendor = product.vendorId;

      if (
        !vendor.flutterwaveSubaccount?.subaccountId ||
        !vendor.flutterwaveSubaccount?.isActive
      ) {
        vendorsWithoutSubaccounts.push(vendor.businessName);
        continue;
      }

      const customPrice = await getCustomPrice(product._id, user.userId);
      const itemPrice = customPrice || product.price;
      const itemTotal = itemPrice * item.quantity;
      const vendorId = vendor._id.toString();

      if (!vendorData.has(vendorId)) {
        vendorData.set(vendorId, {
          subaccountId: vendor.flutterwaveSubaccount.subaccountCode,
          businessName: vendor.businessName,
          itemsTotal: 0,
        });
      }

      const vendorInfo = vendorData.get(vendorId);
      vendorInfo.itemsTotal += itemTotal;
    }

    if (vendorData.size === 0) {
      return NextResponse.json(
        {
          success: false,
          message:
            "No vendors configured for payment processing. Check vendor subaccounts.",
        },
        { status: 400 },
      );
    }

    // Build Subaccounts Split
    const subaccounts = Array.from(vendorData.values()).map((data) => ({
      id: data.subaccountId,
      transaction_split_ratio: Math.round((data.itemsTotal / amount) * 100),
    }));

    const tx_ref = `AFRI-${Date.now()}-${Math.random().toString(36).substring(7)}`;

    // Inside your POST function in /api/payment/initialize/route.js
    const flutterwaveData = {
      tx_ref,
      amount,
      currency: "NGN",
      redirect_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/customer/payment/verify`,
      payment_options: "card,banktransfer,ussd",
      customer: {
        email,
        phonenumber: phone || "",
        name: customerName || email,
      },
      subaccounts,
      meta: {
        // These keys MUST match the verify route exactly
        shipping_name: customerName,
        shipping_phone: phone,
        shipping_address: metadata.address || "",
        shipping_city: metadata.city || "",
        shipping_state: metadata.state || "",
        shipping_zip: metadata.zipCode || "",
        shipping_info: metadata.additionalInfo || "",
        subtotal: metadata.subtotal,
        deliveryFee: metadata.deliveryFee,
        customer_id: user.userId,
        cartItems: JSON.stringify(cartItems),
      },
    };

    const response = await axios.post(
      "https://api.flutterwave.com/v3/payments",
      flutterwaveData,
      { headers: { Authorization: `Bearer ${FLUTTERWAVE_SECRET_KEY}` } },
    );

    return NextResponse.json({
      success: true,
      data: {
        authorization_url: response.data.data.link,
        vendors: Array.from(vendorData.values()).map((v) => v.businessName),
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 },
    );
  }
}
