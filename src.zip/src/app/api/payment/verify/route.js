import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import connectDB from "@/lib/mongodb/config";
import Order from "@/lib/mongodb/models/Order";
import Cart from "@/lib/mongodb/models/Cart";
import Product from "@/lib/mongodb/models/Product";
import Vendor from "@/lib/mongodb/models/Vendor";
import User from "@/lib/mongodb/models/User";
import CustomProductPrice from "@/lib/mongodb/models/CustomProductPrice";
import axios from "axios";
import { sendOrderNotifications } from "@/lib/notifications";

const FLUTTERWAVE_SECRET_KEY = process.env.FLUTTERWAVE_SECRET_KEY;

function verifyToken(request) {
  try {
    const authHeader = request.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) return null;
    const token = authHeader.substring(7);
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
}

function generateOrderNumber() {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `AC-${timestamp}-${random}`;
}

async function getCustomPrice(productId, customerId) {
  try {
    const customPriceDoc = await CustomProductPrice.findOne({
      productId: productId,
      customerId: customerId,
      isActive: true,
      $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }],
    });
    return customPriceDoc ? customPriceDoc.customPrice : null;
  } catch (error) {
    return null;
  }
}

// ✅ NEW: Calculate T+1 settlement date
function calculateExpectedSettlementDate(fromDate = new Date()) {
  const settlementDate = new Date(fromDate);
  settlementDate.setDate(settlementDate.getDate() + 1);

  // Skip weekends
  const dayOfWeek = settlementDate.getDay();
  if (dayOfWeek === 0) settlementDate.setDate(settlementDate.getDate() + 1); // Sunday
  if (dayOfWeek === 6) settlementDate.setDate(settlementDate.getDate() + 2); // Saturday

  return settlementDate;
}

export async function GET(request) {
  try {
    const user = verifyToken(request);
    if (!user) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    await connectDB();

    const { searchParams } = new URL(request.url);
    const transaction_id = searchParams.get("transaction_id");
    const tx_ref = searchParams.get("tx_ref");

    if (!transaction_id || !tx_ref) {
      return NextResponse.json(
        { success: false, message: "ID and Reference required" },
        { status: 400 },
      );
    }

    // 🛡️ GUARD 1: Check for existing order
    const existingOrder = await Order.findOne({
      paymentReference: tx_ref,
      isMasterOrder: true,
    });
    if (existingOrder) {
      console.log("✅ Order already exists:", existingOrder.orderNumber);
      return NextResponse.json({
        success: true,
        data: {
          reference: tx_ref,
          order: {
            id: existingOrder._id,
            orderNumber: existingOrder.orderNumber,
          },
        },
      });
    }

    // Verify with Flutterwave
    console.log("🔄 Verifying payment with Flutterwave:", transaction_id);
    const response = await axios.get(
      `https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`,
      { headers: { Authorization: `Bearer ${FLUTTERWAVE_SECRET_KEY}` } },
    );

    const paymentData = response.data.data;
    if (
      response.data.status !== "success" ||
      paymentData.status !== "successful"
    ) {
      return NextResponse.json(
        { success: false, message: "Payment failed" },
        { status: 400 },
      );
    }

    // 🛡️ GUARD 2: Concurrency check
    const doubleCheck = await Order.findOne({
      paymentReference: tx_ref,
      isMasterOrder: true,
    });
    if (doubleCheck) {
      console.log(
        "✅ Order created by another request:",
        doubleCheck.orderNumber,
      );
      return NextResponse.json({
        success: true,
        data: { order: { orderNumber: doubleCheck.orderNumber } },
      });
    }

    // Reconstruct shipping address
    const metadata = paymentData.meta || {};
    const shippingAddress = {
      fullName:
        metadata.shipping_name || paymentData.customer?.name || "Customer Name",
      phone:
        metadata.shipping_phone ||
        paymentData.customer?.phonenumber ||
        "0000000000",
      address: metadata.shipping_address || "Address Not Provided",
      city: metadata.shipping_city || "City Not Provided",
      state: metadata.shipping_state || "State Not Provided",
      zipCode: metadata.shipping_zip || "",
      additionalInfo: metadata.shipping_info || "",
    };

    // Load cart items
    let cartItems = [];
    let cart = await Cart.findOne({ customerId: user.userId }).populate({
      path: "items.productId",
      populate: { path: "vendorId" },
    });

    if (cart && cart.items?.length > 0) {
      for (const item of cart.items) {
        const customPrice =
          item.customPrice ||
          (await getCustomPrice(item.productId._id, user.userId));
        cartItems.push({
          productId: item.productId,
          quantity: item.quantity,
          customPrice,
        });
      }
    } else {
      // Reconstruct from metadata
      let metaItems = [];
      try {
        metaItems =
          typeof metadata.cartItems === "string"
            ? JSON.parse(metadata.cartItems)
            : metadata.cartItems || [];
      } catch (e) {
        console.error("❌ Meta parse error", e);
      }

      for (const m of metaItems) {
        const prod = await Product.findById(m.productId).populate("vendorId");
        if (prod) {
          const cp =
            m.customPrice || (await getCustomPrice(prod._id, user.userId));
          cartItems.push({
            productId: prod,
            quantity: m.quantity,
            customPrice: cp,
          });
        }
      }
    }

    if (cartItems.length === 0) {
      throw new Error("Cart items missing - cannot create order");
    }

    // Group by vendor
    const vendorOrders = new Map();
    const allItemsForMaster = [];

    for (const item of cartItems) {
      const vId = item.productId.vendorId._id.toString();
      const price = item.customPrice || item.productId.price;
      const orderItem = {
        productId: item.productId._id,
        name: item.productId.name,
        price,
        quantity: item.quantity,
        image: item.productId.images?.[0] || null,
        vendorId: item.productId.vendorId._id,
      };
      allItemsForMaster.push(orderItem);

      if (!vendorOrders.has(vId)) {
        vendorOrders.set(vId, {
          vendorId: item.productId.vendorId._id,
          vendor: item.productId.vendorId, // ✅ Store full vendor object
          items: [],
          subtotal: 0,
        });
      }
      const vOrder = vendorOrders.get(vId);
      vOrder.items.push(orderItem);
      vOrder.subtotal += price * item.quantity;
    }

    // ✅ CREATE MASTER ORDER (no settlement tracking)
    const masterOrder = await Order.create({
      orderNumber: generateOrderNumber(),
      customerId: user.userId,
      isMasterOrder: true,
      shippingAddress,
      paymentMethod: (metadata.paymentMethod || "CARD").toUpperCase(),
      paymentStatus: "PAID",
      paymentReference: tx_ref,
      paymentDetails: {
        amount: paymentData.amount,
        paidAt: new Date(paymentData.created_at),
        transactionId: paymentData.id,
      },
      orderStatus: "CONFIRMED",
      subtotal:
        parseFloat(metadata.subtotal) ||
        paymentData.amount - (parseFloat(metadata.deliveryFee) || 0),
      deliveryFee: parseFloat(metadata.deliveryFee) || 0,
      total: paymentData.amount,
      items: allItemsForMaster,
    });

    console.log(`✅ Created MASTER ORDER: ${masterOrder.orderNumber}`);

    // ✅ CREATE SUB-ORDERS WITH SETTLEMENT TRACKING
    const subOrderIds = [];
    const customerUser = await User.findById(user.userId);
    const paidAt = new Date(paymentData.created_at);
    const expectedSettlementDate = calculateExpectedSettlementDate(paidAt);

    for (const [vId, vData] of vendorOrders.entries()) {
      const vendor = vData.vendor;

      // ✅ Calculate vendor settlement (3% platform commission)
      const platformCommissionRate = 0.03;
      const platformCommission = vData.subtotal * platformCommissionRate;
      const vendorAmount = vData.subtotal - platformCommission;

      console.log(`\n💰 Vendor ${vendor.businessName} Settlement:`);
      console.log(`   Order Total: ₦${vData.subtotal}`);
      console.log(
        `   Platform Commission (3%): ₦${platformCommission.toFixed(2)}`,
      );
      console.log(`   Vendor Amount (97%): ₦${vendorAmount.toFixed(2)}`);
      console.log(
        `   Expected Settlement: ${expectedSettlementDate.toISOString().split("T")[0]}`,
      );

      // ✅ CREATE SUB-ORDER with settlement tracking
      const subOrder = await Order.create({
        orderNumber: `${masterOrder.orderNumber}-V${subOrderIds.length + 1}`,
        customerId: user.userId,
        vendorId: vendor._id,
        isMasterOrder: false,
        masterOrderId: masterOrder._id,
        shippingAddress: masterOrder.shippingAddress,
        paymentMethod: masterOrder.paymentMethod,
        paymentStatus: "PAID",
        orderStatus: "CONFIRMED",
        items: vData.items,
        subtotal: vData.subtotal,
        total: vData.subtotal,

        // ✅ SETTLEMENT TRACKING (Source of truth for vendor balances)
        vendorSettlement: {
          amount: vendorAmount,
          platformCommission: platformCommission,
          platformCommissionRate: platformCommissionRate,
          status: "PENDING", // ✅ Initial status: waiting for Flutterwave settlement
          paidAt: paidAt,
          expectedSettlementDate: expectedSettlementDate,
          flutterwaveTransactionId: paymentData.id, // ✅ For matching with Flutterwave settlements
          flutterwaveSubaccountCode:
            vendor.flutterwaveSubaccount?.subaccountCode, // ✅ RS_xxxxx
          lastReconciledAt: new Date(),
          reconciliationAttempts: 0,
        },
      });

      console.log(`✅ Created SUB-ORDER: ${subOrder.orderNumber}`);
      console.log(`   Settlement Status: ${subOrder.vendorSettlement.status}`);
      console.log(`   Settlement Amount: ₦${subOrder.vendorSettlement.amount}`);

      subOrderIds.push(subOrder._id);

      // Update stock
      for (const item of vData.items) {
        await Product.findByIdAndUpdate(item.productId, {
          $inc: {
            quantity: -item.quantity,
            totalSold: item.quantity,
          },
        });
      }

      // Send notifications
      if (vendor.userId) {
        const vendorUserDoc = await User.findById(vendor.userId).select(
          "firstName lastName email phone",
        );

        if (vendorUserDoc) {
          sendOrderNotifications({
            vendor,
            vendorUser: vendorUserDoc,
            order: subOrder,
            customer: customerUser,
          }).catch((e) => console.error("❌ Notification error:", e));
        } else {
          console.log(
            "⚠️ Vendor user not found for vendor:",
            vendor._id.toString(),
          );
        }
      }
    }

    // Link sub-orders to master
    masterOrder.subOrders = subOrderIds;
    await masterOrder.save();

    // Clear cart
    await Cart.findOneAndUpdate(
      { customerId: user.userId },
      { $set: { items: [] } },
    );

    console.log(`\n🎉 Order completed successfully!`);
    console.log(`   Master Order: ${masterOrder.orderNumber}`);
    console.log(`   Sub-Orders: ${subOrderIds.length}`);
    console.log(`   All settlements initialized with PENDING status\n`);

    return NextResponse.json({
      success: true,
      data: {
        reference: tx_ref,
        order: {
          id: masterOrder._id,
          orderNumber: masterOrder.orderNumber,
        },
      },
    });
  } catch (error) {
    console.error("❌ Verify Error:", error.message);

    // Handle duplicate key errors
    if (error.code === 11000) {
      const existingOrder = await Order.findOne({
        paymentReference: searchParams.get("tx_ref"),
        isMasterOrder: true,
      });

      if (existingOrder) {
        return NextResponse.json({
          success: true,
          data: { order: { orderNumber: existingOrder.orderNumber } },
        });
      }
    }

    return NextResponse.json(
      { success: false, message: error.message },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  return NextResponse.json({ success: true });
}
