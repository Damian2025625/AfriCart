"use client";

import React, { useState, useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  FiSend,
  FiArrowLeft,
  FiPackage,
  FiPhone,
  FiMoreVertical,
  FiImage,
  FiPaperclip,
} from "react-icons/fi";
import toast from "react-hot-toast";
import Link from "next/link";

export default function ChatPage() {
  const params = useParams();
  const router = useRouter();
  const conversationId = params.id;

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [conversation, setConversation] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);
  const pollingInterval = useRef(null);
  const lastMessageIdRef = useRef(null);
  const isFetchingRef = useRef(false);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize everything
  useEffect(() => {
    const initialize = async () => {
      await fetchCurrentUser();
      await fetchConversation();
      await fetchMessages();
    };

    initialize();
  }, [conversationId]);

  // Setup aggressive polling for real-time effect (every 1 second)
  useEffect(() => {
    if (!conversationId || !currentUser) return;

    console.log("🔄 Setting up real-time polling for:", conversationId);

    // Poll every 1 second for new messages
    pollingInterval.current = setInterval(() => {
      fetchNewMessages();
    }, 1000); // 1 second interval for real-time feel

    return () => {
      if (pollingInterval.current) {
        console.log("⏹️ Stopping polling");
        clearInterval(pollingInterval.current);
      }
    };
  }, [conversationId, currentUser]);

  // Fetch current user
  const fetchCurrentUser = async () => {
    try {
      const token = localStorage.getItem("authToken");
      if (!token) {
        router.push("/login");
        return;
      }

      const response = await fetch("/api/user/profile", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (data.success) {
        setCurrentUser(data.user);
        console.log("✅ Current user:", data.user.id);
      }
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };

  // Fetch conversation details
  const fetchConversation = async () => {
    try {
      const token = localStorage.getItem("authToken");

      const response = await fetch(
        `/api/customer/conversations/${conversationId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (data.success) {
        setConversation(data.conversation);
        console.log("✅ Conversation loaded");
      } else {
        toast.error(data.message || "Failed to load conversation");
      }
    } catch (error) {
      console.error("Error fetching conversation:", error);
      toast.error("Failed to load conversation");
    }
  };

  // Initial fetch of all messages
  const fetchMessages = async () => {
    try {
      setLoading(true);

      const token = localStorage.getItem("authToken");

      const response = await fetch(
        `/api/customer/conversations/${conversationId}/messages`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (data.success) {
        const fetchedMessages = data.messages || [];
        setMessages(fetchedMessages);
        
        // Store last message ID for polling
        if (fetchedMessages.length > 0) {
          lastMessageIdRef.current = fetchedMessages[fetchedMessages.length - 1]._id;
        }

        console.log("✅ Messages loaded:", fetchedMessages.length);

        // Mark messages as read
        await markMessagesAsRead();
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch only NEW messages (for polling)
  // Fetch only NEW messages (for polling)
const fetchNewMessages = async () => {
  // Prevent multiple simultaneous fetches
  if (isFetchingRef.current || sending) return; // ✅ Added sending check
  
  try {
    isFetchingRef.current = true;

    const token = localStorage.getItem("authToken");
    const lastMessageId = lastMessageIdRef.current;

    // Build URL with last message ID
    const url = lastMessageId 
      ? `/api/customer/conversations/${conversationId}/messages?after=${lastMessageId}`
      : `/api/customer/conversations/${conversationId}/messages`;

    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const data = await response.json();

    if (data.success && data.messages && data.messages.length > 0) {
      const newMessages = data.messages;
      
      console.log(`📬 ${newMessages.length} new message(s) received`);

      // Add new messages to state
      setMessages((current) => {
        // ✅ Filter out temp messages AND check for duplicates by _id
        const existingIds = new Set(
          current
            .filter(m => !m._id.startsWith('temp-')) // Ignore temp messages
            .map(m => m._id)
        );
        const uniqueNewMessages = newMessages.filter(m => !existingIds.has(m._id));
        
        if (uniqueNewMessages.length > 0) {
          // Update last message ID
          lastMessageIdRef.current = uniqueNewMessages[uniqueNewMessages.length - 1]._id;
          
          // Remove temp messages and add real ones
          const withoutTemp = current.filter(m => !m._id.startsWith('temp-'));
          return [...withoutTemp, ...uniqueNewMessages];
        }
        
        return current;
      });

      // Mark new messages as read
      await markMessagesAsRead();
    }
  } catch (error) {
    console.error("Error polling messages:", error);
  } finally {
    isFetchingRef.current = false;
  }
};

  // Mark messages as read
  const markMessagesAsRead = async () => {
    try {
      if (!currentUser) return;

      const token = localStorage.getItem("authToken");

      await fetch(
        `/api/customer/conversations/${conversationId}/mark-read`,
        {
          method: "PATCH",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch (error) {
      console.error("Error marking messages as read:", error);
    }
  };

  // Send message
  const handleSendMessage = async (e) => {
    e.preventDefault();

    if (!newMessage.trim() || !currentUser) return;

    const messageContent = newMessage.trim();
    setSending(true);

    // Optimistic update - add message immediately
    const optimisticMessage = {
      _id: `temp-${Date.now()}`,
      content: messageContent,
      sender: {
        _id: currentUser.id,
        firstName: currentUser.firstName,
        lastName: currentUser.lastName,
      },
      createdAt: new Date().toISOString(),
      isRead: false,
    };

    setMessages((current) => [...current, optimisticMessage]);
    setNewMessage("");

    try {
      const token = localStorage.getItem("authToken");

      const response = await fetch(
        `/api/customer/conversations/${conversationId}/messages`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            content: messageContent,
          }),
        }
      );

      const data = await response.json();

      if (data.success) {
        // Replace optimistic message with real one
        setMessages((current) => {
          const filtered = current.filter(m => m._id !== optimisticMessage._id);
          return [...filtered, data.message];
        });

        // Update last message ID
        lastMessageIdRef.current = data.message._id;

        console.log("✅ Message sent");
      } else {
        // Remove optimistic message on error
        setMessages((current) => current.filter(m => m._id !== optimisticMessage._id));
        toast.error(data.message || "Failed to send message");
      }
    } catch (error) {
      // Remove optimistic message on error
      setMessages((current) => current.filter(m => m._id !== optimisticMessage._id));
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  // Format timestamp
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            Conversation not found
          </h2>
          <Link
            href="/dashboard/customer"
            className="text-orange-500 hover:text-orange-600 text-sm"
          >
            Go back to home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <FiArrowLeft className="w-5 h-5 text-gray-600" />
            </button>

            <div className="flex items-center gap-3">
              {conversation.vendor?.logoUrl ? (
                <img
                  src={conversation.vendor.logoUrl}
                  alt={conversation.vendor.businessName}
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold">
                  {conversation.vendor?.businessName?.charAt(0) || "V"}
                </div>
              )}

              <div>
                <h1 className="font-bold text-gray-900 text-sm">
                  {conversation.vendor?.businessName}
                </h1>
                <p className="text-xs text-green-500 flex items-center gap-1">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  Online
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <FiPhone className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <FiMoreVertical className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Product Context */}
        {conversation.product && (
          <Link
            href={`/dashboard/customer/products/${conversation.product._id}`}
            className="mt-3 p-3 bg-gray-50 rounded-lg flex items-center gap-3 hover:bg-gray-100 transition-colors"
          >
            {conversation.product.images?.[0] ? (
              <img
                src={conversation.product.images[0]}
                alt={conversation.product.name}
                className="w-12 h-12 rounded-lg object-cover"
              />
            ) : (
              <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center">
                <FiPackage className="text-gray-400 text-xl" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-gray-900 line-clamp-1">
                {conversation.product.name}
              </p>
              <p className="text-xs text-orange-600 font-bold">
                ₦{conversation.product.price.toLocaleString()}
              </p>
            </div>
            <FiArrowLeft className="w-4 h-4 text-gray-400 rotate-180" />
          </Link>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-12">
            <FiPackage className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-sm">
              No messages yet. Start the conversation!
            </p>
          </div>
        ) : (
          messages.map((message) => {
            const isOwn = message.sender._id === currentUser?.id;
            return (
              <div
                key={message._id}
                className={`flex ${isOwn ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[70%] rounded-2xl px-4 py-2 ${
                    isOwn
                      ? "bg-orange-500 text-white rounded-br-none"
                      : "bg-gray-200 text-gray-900 rounded-bl-none"
                  }`}
                >
                  <p className="text-sm wrap-break-word">{message.content}</p>
                  <p
                    className={`text-[10px] mt-1 ${
                      isOwn ? "text-orange-100" : "text-gray-500"
                    }`}
                  >
                    {formatTime(message.createdAt)}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 px-4 py-3 sticky bottom-0">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <button
            type="button"
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <FiPaperclip className="w-5 h-5 text-gray-600" />
          </button>
          <button
            type="button"
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <FiImage className="w-5 h-5 text-gray-600" />
          </button>

          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:border-orange-500 text-sm"
            disabled={sending}
          />

          <button
            type="submit"
            disabled={sending || !newMessage.trim()}
            className="p-2 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            <FiSend className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}