"use client";

import React, { useEffect, useState, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { FiCheck, FiX, FiLoader } from "react-icons/fi";
import toast from "react-hot-toast";

export default function PaymentVerifyPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [status, setStatus] = useState("verifying");
  const [message, setMessage] = useState("Verifying your payment...");
  const [orderNumber, setOrderNumber] = useState(null);

  // 🔥 1. THE LOCK: This prevents double-execution in React Strict Mode
  const hasCalledApi = useRef(false);

  useEffect(() => {
    const transaction_id = searchParams.get("transaction_id");
    const tx_ref = searchParams.get("tx_ref");

    if (transaction_id && tx_ref) {
      // Only call the function if it hasn't been called in this component lifecycle
      if (!hasCalledApi.current) {
        verifyPayment(transaction_id, tx_ref);
      }
    } else if (searchParams.get("status") === "cancelled") {
        setStatus("failed");
        setMessage("Payment was cancelled. Please try again.");
    }
  }, [searchParams]);

  const verifyPayment = async (transaction_id, tx_ref) => {
    // Mark as called immediately
    hasCalledApi.current = true;

    try {
      // ✅ 2. CHECK LOCALSTORAGE (History Guard)
      const verifiedKey = `payment_verified_${tx_ref}`;
      const alreadyVerified = localStorage.getItem(verifiedKey);

      if (alreadyVerified) {
        const cachedOrderNumber = localStorage.getItem(`order_number_${tx_ref}`);
        setStatus("success");
        setMessage("Payment already verified!");
        setOrderNumber(cachedOrderNumber);
        
        // Use REPLACE to avoid back-button loops
        setTimeout(() => {
          router.replace(cachedOrderNumber ? `/dashboard/customer/orders/${cachedOrderNumber}` : "/dashboard/customer/orders");
        }, 1500);
        return;
      }

      const token = localStorage.getItem("authToken");
      if (!token) {
        router.replace("/login");
        return;
      }

      console.log("📤 Calling verification API for:", tx_ref);

      const response = await fetch(
        `/api/payment/verify?transaction_id=${transaction_id}&tx_ref=${tx_ref}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (data.success) {
        const orderNum = data.data.order?.orderNumber;
        
        // ✅ 3. PERSIST THE SUCCESS
        localStorage.setItem(verifiedKey, 'true');
        if (orderNum) {
          localStorage.setItem(`order_number_${tx_ref}`, orderNum);
        }
        
        setStatus("success");
        setMessage("Payment successful! Your order has been placed.");
        setOrderNumber(orderNum);
        
        window.dispatchEvent(new Event("cartUpdated"));
        localStorage.removeItem('pendingOrder');
        
        toast.success("Payment successful! 🎉");

        // ✅ 4. USE router.replace
        // This removes the "Verify" page from browser history so the back button skips it
        setTimeout(() => {
          router.replace(orderNum ? `/dashboard/customer/orders/${orderNum}` : "/dashboard/customer/orders");
        }, 2000);
      } else {
        setStatus("failed");
        setMessage(data.message || "Payment verification failed");
        toast.error(data.message || "Payment failed");
      }
    } catch (error) {
      console.error("❌ Payment verification error:", error);
      setStatus("failed");
      setMessage("An error occurred while verifying payment");
      toast.error("Verification error");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
        {status === "verifying" && (
          <>
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FiLoader className="w-10 h-10 text-blue-600 animate-spin" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Verifying Payment</h2>
            <p className="text-gray-600">{message}</p>
            <p className="text-xs text-gray-400 mt-2">Please do not refresh this page</p>
          </>
        )}

        {status === "success" && (
          <>
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FiCheck className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h2>
            <p className="text-gray-600 mb-4">{message}</p>
            {orderNumber && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-green-800">
                  Order Number: <span className="font-bold">{orderNumber}</span>
                </p>
              </div>
            )}
            <p className="text-xs text-gray-500">Redirecting to your order...</p>
          </>
        )}

        {status === "failed" && (
          <>
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FiX className="w-10 h-10 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Failed</h2>
            <p className="text-gray-600 mb-6">{message}</p>
            <button
              onClick={() => router.replace("/checkout")}
              className="w-full py-3 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors"
            >
              Try Again
            </button>
          </>
        )}
      </div>
    </div>
  );
}