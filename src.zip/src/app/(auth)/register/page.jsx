import React from 'react';
import Link from 'next/link';

export default function AuthPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-orange-50 to-orange-100 px-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Join Africart</h1>
          <p className="text-xl text-gray-600">Choose how you want to get started</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Customer Card */}
          <div className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-shadow">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-4xl">🛒</span>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">I'm a Customer</h2>
              <p className="text-gray-600">Browse and buy amazing African products</p>
            </div>

            <ul className="space-y-3 mb-8">
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Browse thousands of products
              </li>
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Chat with vendors
              </li>
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Secure checkout
              </li>
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Track your orders
              </li>
            </ul>

            <Link
              href="/register/customer"
              className="block w-full py-3 bg-blue-500 text-white text-center rounded-lg font-semibold hover:bg-blue-600 transition-colors"
            >
              Sign Up as Customer
            </Link>
          </div>

          {/* Vendor Card */}
          <div className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-shadow">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-4xl">🏪</span>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">I'm a Vendor</h2>
              <p className="text-gray-600">Sell your products and grow your business</p>
            </div>

            <ul className="space-y-3 mb-8">
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                List unlimited products
              </li>
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Manage your inventory
              </li>
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Chat with customers
              </li>
              <li className="flex items-center text-gray-700">
                <span className="text-green-500 mr-2">✓</span>
                Track your sales
              </li>
            </ul>

            <Link
              href="/register/vendor"
              className="block w-full py-3 bg-orange-500 text-white text-center rounded-lg font-semibold hover:bg-orange-600 transition-colors"
            >
              Sign Up as Vendor
            </Link>
          </div>
        </div>

        <p className="text-center mt-8 text-gray-600">
          Already have an account?{' '}
          <Link href="/login" className="text-orange-500 font-semibold hover:text-orange-600">
            Login here
          </Link>
        </p>
      </div>
    </div>
  );
}